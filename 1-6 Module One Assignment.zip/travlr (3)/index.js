// Import express module
const express = require('express');

// Create an instance of the express app
const app = express();

// Set the port to listen on (you can change the port if needed)
const port = 3000;

// Use express.static middleware to serve static files from the 'public' folder
app.use(express.static('public'));

// Create a basic route to serve the homepage (index.html)
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Start the server and listen on the specified port
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
